function checkLogin(){
    if(sessionStorage.getItem("isLoggedIn")!=="true"){
        window.location.replace("../login.html");
    }
}

checkLogin();
window.addEventListener("pageshow",checkLogin);

const logoutBtn = document.getElementById("logoutBtn");

if(logoutBtn){
    logoutBtn.addEventListener("click", function(){
        sessionStorage.removeItem("isLoggedIn");
        window.location.replace("../login.html");
    });
}